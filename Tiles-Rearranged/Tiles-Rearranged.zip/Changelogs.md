# Changelogs

## 2.0 Overhaul

- Reorganised and renamed some files
- Removed the bathroom tiles because the permissions are different