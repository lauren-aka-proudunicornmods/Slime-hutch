# Changelogs

[Main Page & Readme](https://github.com/lauren-mods/StardewMods/tree/main/Slime-Hutch)

## 2.0
- complete overhaul
- update to newest content patcher
- interior floor and window recolor currently not working and I don't know why! Any help would be appreciated!
